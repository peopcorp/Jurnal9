    </div>
    <!-- JS -->
    <script src="<?php echo base_url('Assets/Landing/vendor/jquery/jquery.min.js'); ?>"></script>
    <script src="<?php echo base_url('Assets/Landing/js/main.js'); ?>"></script>

    <!-- Bootstrap JS -->
    <script src="<?php echo base_url('Assets/Bootstrap/js/bootstrap.bundle.js'); ?>"></script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>