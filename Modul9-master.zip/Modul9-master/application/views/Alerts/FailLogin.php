<div class='alert alert-danger alert-dismissible fade show' role='alert'>
<strong>Password atau Email Salah!</strong> Coba masukkan kembali.
    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
        <span aria-hidden='true'>&times;</span>
    </button>
</div>